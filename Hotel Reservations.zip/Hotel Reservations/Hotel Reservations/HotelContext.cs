﻿namespace Hotel_Reservations
{
    internal class HotelContext
    {
    }
}