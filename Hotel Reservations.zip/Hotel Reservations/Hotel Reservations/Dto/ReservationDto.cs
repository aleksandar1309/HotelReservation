﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hotel_Reservations.Dto
{
    public class ReservationDto
    {
        public int HotelId { get; set; }
        public int Room { get; set; }
        public string StartDate { get; set; }
        public string Endate { get; set; }
    }
}
