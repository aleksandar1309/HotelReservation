﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Hotel_Reservations.Models;
using Microsoft.AspNetCore.Mvc;

namespace Hotel_Reservations.Controllers
{
    public class ReservationController : Controller
    {
        public readonly HotelContext db;

        public ReservationController(HotelContext _db)
        {
            db = _db;
            
        }
        public IActionResult Index()
        {
            return View();
        }

        private IQueryable<Hotel> UpitHotel()
        {
            var Upit = db.Reservation
                 .Include(d => d.Room);
            return Upit;
        }

        public JsonResult GetHotelJson()
        {
            try
            {
                string search = Request.Form["search[value]"];
                string draw = Request.Form["draw"];
                string order = Request.Form["order[0][column]"];
                string orderDir = Request.Form["order[0][dir]"];
                int startRec = System.Convert.ToInt32(Request.Form["start"].ToString() ?? "0");
                int pageSize = System.Convert.ToInt32(Request.Form["length"].ToString() ?? "25");
                var upit = UpitHotel();
                

                upit = upit.OrderBy(d => d.Id);

                var podaci_svi = upit.Select(dp => new Hotel()
                {
                    HotelId = dp.Id,

                    StartDate = dp.StartDate != null ? ((DateTime)dp.StartDate).ToString("dd.MM.yyyy") : string.Empty,
                    EndDate = dp.EndDate != null ? ((DateTime)dp.EndDate).ToString("dd.MM.yyyy") : string.Empty,
                    Room = dp.Room != null ? dp.Romm : string.Empty


                    
                    

                    

                }).ToList();

                upit = upit.OrderBy(d => d.Id).Where(d => d.Id != null);

                




                var podaci = podaci_svi
                        .Skip(startRec)
                        .Take(pageSize)
                        .ToList();
                

                var result = this.Json(new
                {
                    draw = Convert.ToInt32(draw),
                    recordsTotal = UpitHotel().Count(),
                    recordsFiltered = podaci_svi.Count,

                    data = podaci
                });

                return result;
            }


            return this.Json(new
            {
                draw = 0,
                recordsTotal = 0,
                recordsFiltered = 0,

                data = new List<DijetetskiProizvodi>()
            });
        }




        public IActionResult SaveReservation(HotelDto model)
        {
            if (ModelState.IsValid)
            {
                try
                {

                    if (model.Id != 0)
                    {
                        var ht = db.Hotel.FirstOrDefault(x => x.Id == model.Id);

                        ht.Room = model.room;
                        ht.StartDate = model.StartDate;
                        ht.EndDate = model.EndDate;
                        
                        db.SaveChanges();
                    }

                    

            }

                catch (Exception x)
                {
                    TempData["Error"] += "Data not saved" + x.ToString();
                }
            }
        }

    }
}
